library(testthat)
library(BNTR)

test_check("BNTR")
